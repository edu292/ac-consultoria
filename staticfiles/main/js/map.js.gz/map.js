export default function initMap(L, HeatmapOverlay){

    L.Control.TimeDimensionCustom = L.Control.TimeDimension.extend({
        initialize: function(index, options) {
            var playerOptions = {
                buffer: 1,
                minBufferReady: -1
                };
            options.playerOptions = { ...playerOptions, ...(options.playerOptions || {}) };
            L.Control.TimeDimension.prototype.initialize.call(this, options);
            this.index = index;
        },
        _getDisplayDateFormat: function(date) {
            return this.index[date-1];
        }
    });

    class LazyLocationData {
        constructor(length) {
            this.length = length-1
            this._rawCache = new Map();
            this._transformedCache = new Map();
            this.ALL_DATA_KEY = 'all'
        }

        async _getRawData(index) {
            if (this._rawCache.has(index)) {
                return this._rawCache.get(index);
            }

            let dataPromise;
            if (index === this.ALL_DATA_KEY) {
              const allPromises = Array.from({ length: this.length }, (_, i) => this._getRawData(i+1));
              dataPromise = Promise.all(allPromises).then(allData => allData.flat());
            } else {
              dataPromise = fetch(baseURL+index).then(response => response.json());
            }

            this._rawCache.set(index, dataPromise);
            const data = await dataPromise;
            this._rawCache.set(index, data);
            return data;
        }

        async asMarkers(index) {
            if (this._transformedCache.get(index)?.has('markers')) {
              return this._transformedCache.get(index).get('markers');
            }

            const rawData = await this._getRawData(index);

            const markers = rawData.map(point => {
                return L.marker([point.latitude, point.longitude])
                    .bindPopup(
                        L.popup()
                            .setContent('Data: '+point.date+'<br>'+'Tipo de Equipamento: '+point.type)
                    )
                    .bindTooltip(tooltip)
            });

            if (!this._transformedCache.has(index)) {
              this._transformedCache.set(index, new Map());
            }

            this._transformedCache.get(index).set('markers', markers);

            return markers;
        }

        async asHeatmapArray(index) {
            if (this._transformedCache.get(index)?.has('heatmap')) {
              return this._transformedCache.get(index).get('heatmap');
            }

            const rawData = await this._getRawData(index);

            const heatmap = {
              data: rawData.map(p => ({ lat: p.latitude, lng: p.longitude, count: 1 }))
            };

            if (!this._transformedCache.has(index)) {
              this._transformedCache.set(index, new Map());
            }
            this._transformedCache.get(index).set('heatmap', heatmap);

            return heatmap;
        }
    }

    function generateMonthLabels(latestMonth) {
        let timeLabels = []
        for (let monthNumber = 0; monthNumber <= latestMonth-1; monthNumber++) {
            const date = new Date(2025, monthNumber, 1);
            const monthName = new Intl.DateTimeFormat('pt-BR', {month: 'long'}).format(date);
            const capitalizedMonthName = monthName.charAt(0).toUpperCase() + monthName.slice(1);
            const timeLabel = '2025 - ' + capitalizedMonthName
            timeLabels.push(timeLabel)
        }
        timeLabels.push('Total')

        return timeLabels
    }

    async function initializeTimeLabels() {
        const response = await fetch('api/latest-month')
        const data = await response.json()
        const latestMonth = data.latest_month

        let timeLabels = generateMonthLabels(latestMonth)
        const times = Array.from({ length: timeLabels.length }, (_, i) => i+1)

        map.timeDimension = L.timeDimension(
            {times : times, currentTime: new Date(1)}
        );

        var timeDimension = new L.Control.TimeDimensionCustom(timeLabels, {
            autoPlay: false,
            backwardButton: true,
            displayDate: true,
            forwardButton: true,
            limitMinimumRange: 5,
            limitSliders: true,
            loopButton: false,
            maxSpeed: 10,
            minSpeed: 0.1,
            playButton: false,
            playReverseButton: false,
            position: "bottomleft",
            speedSlider: false,
            speedStep: 0.1,
            styleNS: "leaflet-control-timecontrol",
            timeSlider: true,
            timeSliderDragUpdate: false,
            timeSteps: 1
        }).addTo(map);

        return latestMonth
    }

    async function main() {
        const latestMonth = await initializeTimeLabels();

        let currentIndex = 0
        const markersByMonth = new LazyLocationData(latestMonth)
        const totalIndex = latestMonth+1

        map.timeDimension.on('timeload', async function (e) {
            let newIndex = e.time;
            if (newIndex === currentIndex) return;
            currentIndex = newIndex
            const dataIndex = (newIndex === totalIndex) ? 'all' : newIndex;
            console.log(dataIndex)
            const [markers, heatmapArray] = await Promise.all([
                markersByMonth.asMarkers(dataIndex),
                markersByMonth.asHeatmapArray(dataIndex)
            ]);
            cluster.clearLayers();
            cluster.addLayers(markers);
            heatmapLayer.setData(heatmapArray);
        });

        map.timeDimension.fire('timeload', {time: 1});
    }

    const map = L.map('map', {
        zoom: 7,
        center: [-24.61, -51.32],
    });

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(map);

    const geojsonUrl = 'https://raw.githubusercontent.com/giuliano-macedo/geodata-br-states/refs/heads/main/geojson/br_states/br_pr.json';

    fetch(geojsonUrl)
        .then(response => response.json())
        .then(data => {
            L.geoJSON(data, {
                style: {
                    "color": "#007bff",
                    "weight": 3,
                    "opacity": 0.8
                },
            }).addTo(map);
        })
        .catch(error => console.error('Error loading the GeoJSON data:', error));

    const heatmapLayer = new HeatmapOverlay({
        radius: 15,
        blur: 0.8,
        maxOpacity: 0.6,
        scaleRadius: false,
        useLocalExtrema: false,
        latField: 'lat',
        lngField: 'lng',
        valueField: 'count',
        defaultWeight : 1,
    }).addTo(map);

    const cluster = L.markerClusterGroup().addTo(map);

    const tooltip = new L.Tooltip().setContent('Clique para ver mais informações');
    const baseURL = 'api/geoloc/?month='

    main(map);
}